(${input$entity}.isUnderWater())
