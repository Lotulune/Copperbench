/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stage16_installed.init;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.stage16_installed.entity.stage15_agent_projectile_2413811eEntity;
import net.mcreator.stage16_installed.entity.stage15_agent_planned_projectile_2413811eEntity;
import net.mcreator.stage16_installed.Stage16InstalledMod;

public class Stage16InstalledModEntities {
	public static EntityType<stage15_agent_planned_projectile_2413811eEntity> STAGE_15_AGENT_PLANNED_PROJECTILE_2413811E = register("stage_15_agent_planned_projectile_2413811e",
			EntityType.Builder.<stage15_agent_planned_projectile_2413811eEntity>of(stage15_agent_planned_projectile_2413811eEntity::new, MobCategory.MISC).clientTrackingRange(64).updateInterval(1).sized(0.5f, 0.5f));
	public static EntityType<stage15_agent_projectile_2413811eEntity> STAGE_15_AGENT_PROJECTILE_2413811E = register("stage_15_agent_projectile_2413811e",
			EntityType.Builder.<stage15_agent_projectile_2413811eEntity>of(stage15_agent_projectile_2413811eEntity::new, MobCategory.MISC).clientTrackingRange(64).updateInterval(1).sized(0.5f, 0.5f));

	public static void load() {
	}

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		ResourceLocation id = ResourceLocation.fromNamespaceAndPath(Stage16InstalledMod.MODID, registryname);
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, id, (EntityType<T>) entityTypeBuilder.build(id.toString()));
	}
}