/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stage16_installed.init;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class Stage16InstalledModEntityRenderers {
	public static void clientLoad() {
		net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(Stage16InstalledModEntities.STAGE_15_AGENT_PLANNED_PROJECTILE_2413811E, ThrownItemRenderer::new);
		net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(Stage16InstalledModEntities.STAGE_15_AGENT_PROJECTILE_2413811E, ThrownItemRenderer::new);
	}
}