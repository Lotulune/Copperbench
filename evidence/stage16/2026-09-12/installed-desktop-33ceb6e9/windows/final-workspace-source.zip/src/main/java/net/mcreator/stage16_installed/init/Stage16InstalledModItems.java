/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stage16_installed.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.stage16_installed.item.stage15_agent_item_1eb7223aItem;
import net.mcreator.stage16_installed.Stage16InstalledMod;

import java.util.function.Function;

public class Stage16InstalledModItems {
	public static Item STAGE_15_AGENT_ITEM_1EB_7223A;

	public static void load() {
		STAGE_15_AGENT_ITEM_1EB_7223A = register("stage_15_agent_item_1eb_7223a", stage15_agent_item_1eb7223aItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(Stage16InstalledMod.MODID, name));
		return (I) Items.registerItem(key, supplier.apply(new Item.Properties()));
	}

	private static <I extends Item> I register(String name, java.util.function.Supplier<? extends I> supplier) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(Stage16InstalledMod.MODID, name));
		return (I) Items.registerItem(key, supplier.get());
	}
}