/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stage16_cold.init;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.stage16_cold.entity.stage15_agent_projectile_bb4c0046Entity;
import net.mcreator.stage16_cold.entity.stage15_agent_planned_projectile_bb4c0046Entity;
import net.mcreator.stage16_cold.Stage16ColdMod;

public class Stage16ColdModEntities {
	public static EntityType<stage15_agent_planned_projectile_bb4c0046Entity> STAGE_15_AGENT_PLANNED_PROJECTILE_BB_4C_0046 = register("stage_15_agent_planned_projectile_bb_4c_0046",
			EntityType.Builder.<stage15_agent_planned_projectile_bb4c0046Entity>of(stage15_agent_planned_projectile_bb4c0046Entity::new, MobCategory.MISC).clientTrackingRange(64).updateInterval(1).sized(0.5f, 0.5f));
	public static EntityType<stage15_agent_projectile_bb4c0046Entity> STAGE_15_AGENT_PROJECTILE_BB_4C_0046 = register("stage_15_agent_projectile_bb_4c_0046",
			EntityType.Builder.<stage15_agent_projectile_bb4c0046Entity>of(stage15_agent_projectile_bb4c0046Entity::new, MobCategory.MISC).clientTrackingRange(64).updateInterval(1).sized(0.5f, 0.5f));

	public static void load() {
	}

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		ResourceLocation id = ResourceLocation.fromNamespaceAndPath(Stage16ColdMod.MODID, registryname);
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, id, (EntityType<T>) entityTypeBuilder.build(id.toString()));
	}
}