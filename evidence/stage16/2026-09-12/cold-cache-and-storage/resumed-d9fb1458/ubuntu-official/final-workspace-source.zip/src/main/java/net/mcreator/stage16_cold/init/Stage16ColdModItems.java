/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stage16_cold.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.stage16_cold.item.stage15_agent_item_bb4c0046Item;
import net.mcreator.stage16_cold.Stage16ColdMod;

import java.util.function.Function;

public class Stage16ColdModItems {
	public static Item STAGE_15_AGENT_ITEM_BB_4C_0046;

	public static void load() {
		STAGE_15_AGENT_ITEM_BB_4C_0046 = register("stage_15_agent_item_bb_4c_0046", stage15_agent_item_bb4c0046Item::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(Stage16ColdMod.MODID, name));
		return (I) Items.registerItem(key, supplier.apply(new Item.Properties()));
	}

	private static <I extends Item> I register(String name, java.util.function.Supplier<? extends I> supplier) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(Stage16ColdMod.MODID, name));
		return (I) Items.registerItem(key, supplier.get());
	}
}