package net.mcreator.stage16_cold.item;

import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class stage15_agent_item_bb4c0046Item extends Item implements net.fabricmc.fabric.api.item.v1.FabricItem {
	public stage15_agent_item_bb4c0046Item(Item.Properties properties) {
		super(properties);
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.EAT;
	}
}