/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stage16_cold.init;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class Stage16ColdModEntityRenderers {
	public static void clientLoad() {
		net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(Stage16ColdModEntities.STAGE_15_AGENT_PLANNED_PROJECTILE_BB_4C_0046, ThrownItemRenderer::new);
		net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(Stage16ColdModEntities.STAGE_15_AGENT_PROJECTILE_BB_4C_0046, ThrownItemRenderer::new);
	}
}